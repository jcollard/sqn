Space Quest 2 savegames

These savegames are for Version 2.0F of Space Quest 2 for the PC, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ2. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

x - Xenon Orbital Station 4
l - Labion
a - Vohaul's Asteroid

Here's a breakdown of which folders have savegames for which places:

save1 - Xenon Orbital Station 4, Labion start
save2 - Labion before going through the swamp
save3 - Labion just after going through the swamp
save4 - Labion during and after the cave maze
save5 - Labion in shuttle, Vohaul's Asteroid start
save6 - Even more Vohaul's Asteroid
save7 - Escaping from Vohaul's Asteroid, Endgame
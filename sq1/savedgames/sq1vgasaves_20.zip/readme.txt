Space Quest 1 VGA savegames

These savegames are for Version 2.0 of Space Quest 1 VGA for the PC, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ1VGA. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

a - the Arcada
p - the Arcada escape pod
k - Kerona
ku - the Kerona underground caves
uf - Ulence Flats
ss - the space ship you buy from Kerona
d - the Deltaur

Here's a breakdown of which folders have savegames for which places:

save1 - The Arcada, Escape Pod, Kerona
save2 - More Kerona, Skimmer Sequence, Ulence Flats
save3 - More Ulence Flats, Space Ship, Deltaur, and Endgame
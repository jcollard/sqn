Space Quest 6 for Windows savegames

These savegames are for Version 1.11 of Space Quest 6 for Windows, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ6. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

p - Polysorbate LX
d - the Deepship 86
db - Delta Burksilon V
ss - inside the shuttle
c  - Cyberspace
s - inside Stellar

Here's a breakdown of which folders have savegames for which places:

save1 - Polysorbate 60 start
save2 - More Polysorbate 60
save3 - Even more Polysorbate 60, Deepship start, Delta Burksilon V
save4 - The Deepship again, travelling in the a shuttle
save5 - Delta Burksilon V again, Polysorbate 60 again, Cyberspace start
save6 - More cyberspace, Delta Burksilon V yet again, inside Stellar
save7 - Still inside Stellar
save8 - Still traipsing around inside Stellar, end game
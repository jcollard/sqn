Space Quest 4 CD version for DOS savegames

These savegames are for Version 1.0 of the Space Quest 4 CD version for MS-DOS for the PC, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ4. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

xs - the streets of Xenon
so - the Xenon sewer office
s  - the Xenon sewers
xd - the Xenon super-computer dome
e  - Estros
lbl- the Latex Babes' lair
gg - the Galaxy Galleria
uf - Ulence Flats

Here's a breakdown of which folders have savegames for which places:

save1 - Xenon Streets & Dome (1st time), Estros start
save2 - More Estros, the Latex Babes' Lair, Galaxy Galleria
save3 - Galaxy Galleria end, Ulence Flats, Xenon Dome (2nd time), Endgame
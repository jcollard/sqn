Space Quest III soundblaster driver fix

This patch includes a more suitable sound driver for Space Quest 3, which enables you to listen to special sound effects (like Roger saying "Where am I"). This readme file contains information how to install the fix.

Step 1) First, you'll need to know which IRQ number your soundblaster card is using:

DOS
In the DOS command line type "set" and locate the line that reads "BLASTER". Example: if the line reads "BLASTER=A220 I5 D1", it's using IRQ5.

WINDOWS
If you're using Windows, open the Device Manager: Click Start, point to Settings, and then click Control Panel. Double-click System, click the Hardware tab, and then click Device Manager. Double click on "Sound, video and game controllers" and locate your soundcard. Double click on its name. A new window pops up, click on the Resource tab and locate the Interrupt Request in the resource settings listing. The number showing is the IRQ number your soundblaster uses under Windows.

If the IRQ number reads 5 or 7, you should use the SNDBLAST.DRV file in folder IRQ5AND7. If the number reads 3 or 7, you'll need the SNDBLAST.DRV in folder IRQ3AND7. If it reads another number but 3, 5 or 7, than you're out of luck. Read the ALTERNATIVES chapter for a possible solution.

INSTALLING THE FIX
Step 2) Copy the right SNDBLAST.DRV file into the SQ3 folder. Step 3) Run INSTALL.EXE and set the music to Sound Blaster. Step 4) Run the game and enjoy!

Tested with DOS 6.22 English, the Creative Soundblaster CT4170 and Space Quest 3 version 1.018 DOS English (supplied with the Space Quest collection).

ALTERNATIVES
If you're IRQ differs, you might want to do the following:
1) Get GoSierra v3 (offered with this download).
2) Install KQ1SCI (not offered with this download) and put the GoSierra executable into the folder. 
3) Run GoSierra and let it patch the SNDBLAST.DRV file. 
4) Copy the SNDBLAST.DRV file into the SQ3 folder. 
5) Run INSTALL.EXE and set the music to Sound Blaster. 
6) Run the game and enjoy!
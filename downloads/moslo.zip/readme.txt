

    The Mo'Slo v1.32a evaluation package should contain four files: this
    file, MOSLO132.TXT, MOSLO132.WRI, and MOSLO.COM.

    Before installing Mo'Slo v1.32, please print and read MOSLO132.TXT
    or MOSLO132.WRI.

    MOSLO132.WRI is for Windows users and may be read and printed from
    MS WRITE, MS WORDPAD, or MS WORD.

    MOSLO132.TXT may be printed on a non-PostScript printer using the
    DOS COPY command -- turn on your printer and enter the following
    DOS command line, substituting the correct drive and path for
    'd:\path\' (you may also need to substitute 'LPT1' or 'LPT2' for
    'PRN', depending on how many printers you have):

           COPY d:\path\MOSLO132.TXT PRN:

    You may view and/or print MOSLO132.TXT from within a text editor,
    but since the file is pre-formatted you must set your printer's
    margins to '0' in order to get a legible printed copy.

    Note that this is an evaluation copy of Mo'Slo, and is intended as
    a 'preview' of some of the basic functionality of our commercial
    product Mo'Slo Deluxe. Mo'Slo Deluxe includes many features not
    found in version 1.32a, including speed adjustment in 0.1% increments,
    speed adjustment while running, 'quick load' mode (especially useful
    for Ultima), and the capability to run batch files. For more info
    visit our WWW site:

          http://www.hpaa.com/moslo

    Thanks for trying Mo'Slo!


Space Quest 3 savegames

These savegames are for Version 1.018 of Space Quest 3 for the PC, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ3. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

f - Garbage Freighter
a - The Aluminum Mallard
p - Phleebhut
m - Monolith Burger
o - Ortega
p - Pestulon

Here's a breakdown of which folders have savegames for which places:

save1 - Garbage Freighter, first trip in the Aluminum Mallard
save2 - Phleebhut, Monolith Burger, Ortega start
save3 - More Ortega, Pestulon
save4 - More Pestulon, Endgame
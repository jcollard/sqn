Space Quest 1 EGA savegames

These savegames are for Version 2.2 of Space Quest 1 EGA for the PC, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ1EGA. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

a - the Arcada
p - the Arcada escape pod
k - Kerona
ku - the Kerona underground caves
uf - Ulence Flats
ss - the space ship you buy from Kerona
d - the Deltaur

Here's a breakdown of which folders have savegames for which places:

save1 - The Arcada, Escape Pod, just before leaving pod on Kerona
save2 - Kerona
save3 - More Kerona, skimmer sequence, arrive at Ulence Flats
save4 - Ulence Flats, Space Ship, and Deltaur
save5 - More Deltaur
save6 - Even More Deltaur, and Endgame
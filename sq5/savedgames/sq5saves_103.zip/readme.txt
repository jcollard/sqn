Space Quest 5 savegames

These savegames are for version 1.03 of Space Quest 5 for the PC, unpatched. I can't guarantee they'll work in any other version of the game, although you're welcome to try.

These savegames will probably work best if you extract the folders to either a floppy disk, or the folder you've installed your game to, ex. C:\Sierra\SQ5. That's just a friendly suggestion, though.

The games are labelled as follows:

(location)-(description)

The location abbreviations I used are:

s - StarCon Academy
e - the Eureka
k - Kiz Urazgubi
ws- W-D40's ship
sb - the SpaceBar
k2 - Klorox II
t - Thrakus
g - Genetix
go - the Goliath

Here's a breakdown of which folders have savegames for which places:

save1 - StarCon Academy, the Eureka (Gangularis pickup)
save2 - The Eureka (Peeyu pickup), Kiz Urazgubi, W-D40's ship, SpaceBar start
save3 - More SpaceBar, Klorox II
save4 - Thrakus, rescuing Cliffy, Genetix start
save5 - More Genetix, Goliath start
save6 - More Goliath, and Endgame